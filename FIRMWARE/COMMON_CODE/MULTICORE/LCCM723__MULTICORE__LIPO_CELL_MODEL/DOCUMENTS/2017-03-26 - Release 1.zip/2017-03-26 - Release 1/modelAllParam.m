% Cycle through all the parameters in parameterSet.mat
load('parameterSet.mat')
totalSets = size(parameterSet,1);
for m=1:totalSets-1
    figure
    clearvarlist = ['clearvarlist';setdiff(who,{'m';'totalSets'})];
    clear(clearvarlist{:});
    paramChoice = m;
    cell_sim_model_r1;
end
