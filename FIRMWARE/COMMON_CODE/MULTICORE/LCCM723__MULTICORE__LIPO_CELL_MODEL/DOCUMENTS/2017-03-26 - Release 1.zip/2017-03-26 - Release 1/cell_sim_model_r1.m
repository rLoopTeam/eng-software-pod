% rLoop Cell Simulation Model
% ---------------------------------------------------------------
% Original Author: Aaron Camere
% Version R1 (3/26/2017)
% Simulates discharge of a Revolectrix YS5000 1S RL
% Model can simulate constant power, constant current, or constant resist
% The cell is connected to a piece of phase change material
% Refer to Model Documentation at the link below


% If no parameter set was chosen, default to 1
if not(exist('paramChoice'))        %#ok<EXIST>
    paramChoice = 1;
end

% Load simulation parameters
load('parameterSet.mat')
parameterCount = size(parameterSet,2)-3;

% Define all parameters, loop through parameter count
for a=1:parameterCount
    % Get name of parameter
    parameterName = char(parameterSet(1,a+3)); % Get name of param
    % Ignore units in the parameter string
    unitsIndex = findstr(parameterName,'[');
    parameterName = parameterName(1:unitsIndex-1);
    % Extract value
    parameterVal = cell2mat(parameterSet(paramChoice+1,a+3));
    % If the parameter doesn't exist in the workspace, define here
    if not(exist(parameterName)) %#ok<EXIST>
        eval(strcat(parameterName,'=',num2str(parameterVal),';'));
    end
end
% Load simulation inputs, OCV curve polynomial coefficients and dVdT data
load('modelinputs.mat')

% Simulation vector initialization
timeVect = 0:timeStep:timeTot;                      % Time in seconds
voltOCVVect = zeros(size(timeVect));                % OCV vector
voltVect = zeros(size(timeVect));                   % Cell voltage
currVect = zeros(size(timeVect));                   % Cell current
powerVect = zeros(size(timeVect));                  % Cell power
effHeatCap = zeros(size(timeVect));                 % PCM Heat Capacity

% The following are system states, since they require initial condition,
% they are one element larger than other system outputs
tempCellVect = zeros(1,size(timeVect,2)+1);         % Cell temperature
tempSensVect = zeros(1,size(timeVect,2)+1);         % Sensor temperature
tempPCMVect = zeros(1,size(timeVect,2)+1);          %
DODVect = zeros(1,size(timeVect,2)+1);

% Set initial conditions
tempCellVect(1) = tempCellInit;
tempSensVect(1) = tempCellInit;
tempPCMVect(1) = tempPCMInit;
DODVect(1) = DODInit;

% This variable stops cell usage when set to 1, but continues simulating 
% temperature evolution. Useful for simulating cooldown time.
stopCell = 0;

% Loop through time steps
for n=1:size(timeVect,2)
    
    % Calculate open circuit voltage & entropy, both functions of SOC
    voltOCVVect(n) = polyval(OCVConst,1-DODVect(n))
    dVdT = -interp1(EntropyCurve(:,1),EntropyCurve(:,2),real(1-DODVect(n)),'linear','extrap');
    
    % Resistance calculation - Equation 5
    resist1 = resistPost1*exp(-tempCellVect(n)/resistPre1);
    resist2 = resistPost1*exp(-tempCellVect(n)/resistPre1);
    resist = (resist1+resist2)*resistMultiplier;

    % Calculate cell current, voltage, and power
    % Constant power case
    if loadPower ~= 0 && stopCell == 0
        % Equation 2
        voltVect(n) = 1/2*(voltOCVVect(n) + sqrt(voltOCVVect(n)^2-4*loadPower*resist));
        currVect(n) = loadPower/voltVect(n);
        powerVect(n) = voltVect(n)*currVect(n);
    % Constant current case
    elseif loadCurrent ~= 0 && stopCell == 0
        % Equation 1
        voltVect(n) = voltOCVVect(n) - loadCurrent*resist;
        currVect(n) = loadCurrent;
        powerVect(n) = voltVect(n)*currVect(n);
    % Constant resistance case
    elseif stopCell == 0
        % Equation 3
        voltVect(n) = loadResist/(resist+loadResist)*voltOCVVect(n);
        currVect(n) = voltVect(n)/loadResist;
        powerVect(n) = voltVect(n)*currVect(n);
    % If stopCell is one, don't use cell. Voltage = OCV
    else
        currVect(n) = 0;
        voltVect(n) = voltOCVVect(n);
        powerVect(n) = 0;
    end
    
    % Cell thermal caculation - Equation 6
    % Irreversible resistive heat generation
    intIrrHeat = currVect(n)^2*resist;
    % Reversible entropic heat generation
    intRevHeat = dVdT/1000*(tempCellVect(n)+273.15)*currVect(n);
    % Cooling due to ambient
    ambCool = 1/resistThAmb*(tempCellVect(n)-tempAmb);
    % Cooling due to PCM
    pcmHeat = 1/resistThPCM*(tempCellVect(n)-tempPCMVect(n));
    % Temperature rate of change
    tempRate = 1/massCell/specHeatCell*(intIrrHeat + intRevHeat - ambCool - pcmHeat);
    
    % PCM thermal calculation
    % PCM specific heat capacity calculation - Equation 8
    meltFunc = 1/sqrt(pi*tempRange^2)*exp(-1*(tempPCMVect(n)-tempMelt)^2/tempRange^2);
    effHeatCap(n) = (specHeatPCM + meltFunc*heatMelt);
    % Temperature rate of change - Equation 7
    tempRatePCM = 1/massPCM/effHeatCap(n)*(pcmHeat);
 
    % Sensor calculation - Equation 9
    tempRateSense = 1/timeConstSense*(-tempSensVect(n)+tempCellVect(n));
    
    % Integrate to next time step
    DODVect(n+1) = DODVect(n) + currVect(n)*timeStep/cellCap;
    tempCellVect(n+1) = tempCellVect(n) + tempRate*timeStep;
    tempPCMVect(n+1) = tempPCMVect(n) + tempRatePCM*timeStep;
    tempSensVect(n+1) = tempSensVect(n) + tempRateSense*timeStep;
    
    
    % If cell discharges fully, stop discharging
    if voltVect(n) < 3.06
        stopCell = 1;
    end
end

% Generate plot
% Voltage and OCV
subplot(311)
hold on
plot(timeVect,voltVect)
plot(timeVect,voltOCVVect,'--')
legend('Cell','OCV')    
ylabel('Voltage')
% Current
subplot(312)
hold on
plot(timeVect,currVect)
ylabel('Current (A)')
% Temperature: cell, sensor, and PCM
subplot(313)
hold on
plot(timeVect,tempCellVect(1:end-1))
plot(timeVect,tempPCMVect(1:end-1),'--')
plot(timeVect,tempSensVect(1:end-1),'g')
legend('Cell','PCM','Sensor')
ylabel('Temperature (degC)')
xlabel('Time (sec)')

% If there exists a data file for comparison, make a compare plot
if not(strcmp('N/A',parameterSet(paramChoice+1,2)))
    % GNU Octave load instructions
    if (exist ('OCTAVE_VERSION', 'builtin') > 0)
        realData = csvread(char(parameterSet(paramChoice+1,2)));
        realData = realData(:,2:end);
    % Matlab load instructions
    else
        realData = importdata(char(parameterSet(paramChoice+1,2)));
        realData = realData.data;
    end
    % Voltage
    subplot(311)
    hold on
    plot(realData(:,1)-timeOffset,realData(:,2),'r')
    legend('Model','Data')
    xlim([0 timeTot]);
    % Current
    subplot(312);
    plot(realData(:,1)-timeOffset,realData(:,4),'r')
    xlim([0 timeTot]);
    % Temperature
    subplot(313);
    hold on;
    % Check data file format, two file formats exist
    if size(realData,2) == 10
        plot(realData(:,1)-timeOffset,realData(:,9),'r')
    else
        plot(realData(:,1)-timeOffset,realData(:,5),'r')
    end
    xlim([0 timeTot]);
end